const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Get current status (is running?)
app.get('/api/status', (req, res) => {
  const row = db.prepare('SELECT * FROM sessions WHERE end_time IS NULL ORDER BY id DESC LIMIT 1').get();
  if (row) {
    res.json({ running: true, session: row });
  } else {
    res.json({ running: false });
  }
});

// Start a session
app.post('/api/start', (req, res) => {
  const { note } = req.body;
  const startTime = new Date().toISOString();
  
  // Check if already running
  const running = db.prepare('SELECT * FROM sessions WHERE end_time IS NULL').get();
  if (running) {
    return res.status(400).json({ error: 'Session already running' });
  }

  const info = db.prepare('INSERT INTO sessions (start_time, note) VALUES (?, ?)').run(startTime, note || '');
  res.json({ success: true, id: info.lastInsertRowid, start_time: startTime });
});

// Stop a session
app.post('/api/stop', (req, res) => {
  const endTime = new Date().toISOString();
  
  const running = db.prepare('SELECT * FROM sessions WHERE end_time IS NULL ORDER BY id DESC LIMIT 1').get();
  if (!running) {
    return res.status(400).json({ error: 'No running session' });
  }

  const start = new Date(running.start_time);
  const end = new Date(endTime);
  const duration = Math.floor((end - start) / 1000); // seconds

  db.prepare('UPDATE sessions SET end_time = ?, duration = ? WHERE id = ?').run(endTime, duration, running.id);
  
  res.json({ success: true, duration });
});

// Get all sessions (for heatmap and logs)
app.get('/api/sessions', (req, res) => {
  const rows = db.prepare('SELECT * FROM sessions WHERE end_time IS NOT NULL ORDER BY start_time DESC').all();
  res.json(rows);
});

// Delete a session
app.delete('/api/sessions/:id', (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM sessions WHERE id = ?').run(id);
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
